import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  Banknote,
  Globe2,
  Instagram,
  Mail,
  MapPin,
  Phone,
  Server,
  ShieldCheck,
  Clock,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import logoAsset from "@/assets/seunsystems-logo.png.asset.json";
const logo = logoAsset.url;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Seunsystems Fintech Global | Cross-Border Payments & FX" },
      {
        name: "description",
        content:
          "Seunsystems Fintech Global delivers cross-border payments, foreign exchange and IT managed services for businesses in Nigeria and beyond.",
      },
      { property: "og:title", content: "Seunsystems Fintech Global" },
      {
        property: "og:description",
        content:
          "Cross-border payments, foreign exchange and IT managed services from Ikeja, Lagos.",
      },
    ],
  }),
  component: Home,
});

const services = [
  {
    icon: Globe2,
    title: "Cross-Border Payments",
    body: "Send and receive money across borders with transparent pricing, fast settlement and full compliance support for individuals and businesses.",
  },
  {
    icon: Banknote,
    title: "Foreign Exchange",
    body: "Competitive rates on major currency pairs, corporate FX advisory and hedging support so your margins stay protected.",
  },
  {
    icon: Server,
    title: "IT Managed Services",
    body: "Infrastructure, cloud, network and endpoint management — proactive monitoring and support that keeps your business running.",
  },
];

const stats = [
  { value: "24/7", label: "Support coverage" },
  { value: "50+", label: "Currency corridors" },
  { value: "100%", label: "Compliance-first" },
];

const why = [
  {
    icon: ShieldCheck,
    title: "Secure & compliant",
    body: "KYC/AML-aligned processes and encrypted transaction handling on every payout.",
  },
  {
    icon: Clock,
    title: "Fast settlement",
    body: "Most corridors settle same-day, with clear status updates end to end.",
  },
  {
    icon: Users,
    title: "People you can reach",
    body: "A Lagos-based team that answers the phone and knows your account.",
  },
];

function Home() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
          <a href="#top" className="flex items-center gap-3">
            <img
              src={logo}
              alt="Seunsystems Fintech Global logo"
              className="h-10 w-10 rounded-lg object-cover"
              width={40}
              height={40}
            />
            <span className="hidden text-sm font-semibold leading-tight sm:block">
              Seunsystems
              <span className="block text-xs font-medium text-muted-foreground">
                Fintech Global
              </span>
            </span>
          </a>
          <nav className="hidden items-center gap-7 text-sm font-medium text-muted-foreground md:flex">
            <a className="transition-colors hover:text-foreground" href="#services">
              Services
            </a>
            <a className="transition-colors hover:text-foreground" href="#why">
              Why us
            </a>
            <a className="transition-colors hover:text-foreground" href="#about">
              About
            </a>
            <a className="transition-colors hover:text-foreground" href="#contact">
              Contact
            </a>
          </nav>
          <Button asChild size="sm">
            <a href="tel:+2347065759842">Talk to us</a>
          </Button>
        </div>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="relative overflow-hidden bg-ink text-ink-foreground">
          <div
            aria-hidden
            className="pointer-events-none absolute -right-32 -top-40 h-[34rem] w-[34rem] rounded-full bg-brand-gradient opacity-25 blur-3xl"
          />
          <div className="relative mx-auto grid max-w-6xl gap-14 px-5 py-24 md:grid-cols-[1.15fr_0.85fr] md:items-center md:py-32">
            <div>
              <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-primary">
                paywithnaira.name.ng
              </span>
              <h1 className="mt-6 text-4xl font-extrabold leading-[1.05] sm:text-5xl lg:text-6xl">
                Move money across borders.{" "}
                <span className="text-brand-gradient">Keep your business running.</span>
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-ink-foreground/70 sm:text-lg">
                Seunsystems Fintech Global combines cross-border payments, foreign exchange
                and IT managed services under one trusted partner — built for African
                businesses trading with the world.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Button asChild size="lg">
                  <a href="#contact">
                    Start a transfer <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
                <Button asChild size="lg" variant="secondary">
                  <a href="#services">Explore services</a>
                </Button>
              </div>
              <dl className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-white/10 pt-8">
                {stats.map((s) => (
                  <div key={s.label}>
                    <dt className="text-2xl font-bold text-primary">{s.value}</dt>
                    <dd className="mt-1 text-xs text-ink-foreground/60">{s.label}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="relative mx-auto w-full max-w-sm">
              <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-elevate backdrop-blur">
                <img
                  src={logo}
                  alt="Seunsystems Fintech Global — Solutions & Services"
                  className="w-full rounded-2xl bg-white object-contain p-4"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Services */}
        <section id="services" className="mx-auto max-w-6xl px-5 py-24">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
            What we do
          </p>
          <h2 className="mt-3 max-w-2xl text-3xl font-bold sm:text-4xl">
            Three practices, one accountable partner
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {services.map((s) => (
              <article
                key={s.title}
                className="group rounded-2xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:shadow-elevate"
              >
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-brand-gradient">
                  <s.icon className="h-6 w-6 text-primary-foreground" />
                </span>
                <h3 className="mt-5 text-lg font-semibold">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Why us */}
        <section id="why" className="bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-24">
            <h2 className="max-w-2xl text-3xl font-bold sm:text-4xl">
              Why businesses choose Seunsystems
            </h2>
            <div className="mt-12 grid gap-10 sm:grid-cols-3">
              {why.map((w) => (
                <div key={w.title}>
                  <w.icon className="h-7 w-7 text-primary" />
                  <h3 className="mt-4 text-base font-semibold">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{w.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About */}
        <section id="about" className="mx-auto max-w-6xl px-5 py-24">
          <div className="grid gap-12 md:grid-cols-2 md:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                About us
              </p>
              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
                Solutions &amp; services, from Ikeja to the world
              </h2>
              <p className="mt-6 text-sm leading-relaxed text-muted-foreground sm:text-base">
                Seunsystems Fintech Global is a Lagos-based financial technology and
                technology services company. We help importers, exporters, students,
                freelancers and enterprises settle payments internationally, access fair
                exchange rates, and run reliable IT infrastructure — without juggling
                multiple vendors.
              </p>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
                Everything we build runs on the same principle: clear pricing, real people,
                and systems that stay up.
              </p>
            </div>
            <div className="rounded-3xl border border-border bg-card p-8 shadow-elevate">
              <h3 className="text-lg font-semibold">Get a rate today</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Call or message us with your corridor and amount, and we&apos;ll quote you
                straight away.
              </p>
              <div className="mt-6 space-y-3 text-sm">
                <a
                  className="flex items-center gap-3 rounded-xl border border-border px-4 py-3 transition-colors hover:bg-secondary"
                  href="tel:+2347065759842"
                >
                  <Phone className="h-4 w-4 text-primary" /> 07065759842
                </a>
                <a
                  className="flex items-center gap-3 rounded-xl border border-border px-4 py-3 transition-colors hover:bg-secondary"
                  href="mailto:paywithnaira@gmail.com"
                >
                  <Mail className="h-4 w-4 text-primary" /> paywithnaira@gmail.com
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="bg-ink text-ink-foreground">
          <div className="mx-auto max-w-6xl px-5 py-24">
            <h2 className="text-3xl font-bold sm:text-4xl">Contact us</h2>
            <p className="mt-3 max-w-xl text-ink-foreground/70">
              Visit the office, call, or reach out on Instagram — we respond quickly.
            </p>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[
                {
                  icon: MapPin,
                  label: "Office",
                  value: "19a Allen Avenue, Oshopey Plaza, Ikeja, Lagos",
                  href: "https://maps.google.com/?q=Oshopey+Plaza+19a+Allen+Avenue+Ikeja+Lagos",
                },
                { icon: Phone, label: "Phone", value: "07065759842", href: "tel:+2347065759842" },
                {
                  icon: Mail,
                  label: "Email",
                  value: "paywithnaira@gmail.com",
                  href: "mailto:paywithnaira@gmail.com",
                },
                {
                  icon: Instagram,
                  label: "Instagram",
                  value: "@byseunsystems",
                  href: "https://instagram.com/byseunsystems",
                },
              ].map((c) => (
                <a
                  key={c.label}
                  href={c.href}
                  target={c.href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="rounded-2xl border border-white/10 bg-white/5 p-6 transition-colors hover:border-primary/50"
                >
                  <c.icon className="h-5 w-5 text-primary" />
                  <p className="mt-4 text-xs uppercase tracking-[0.14em] text-ink-foreground/50">
                    {c.label}
                  </p>
                  <p className="mt-1 text-sm font-medium">{c.value}</p>
                </a>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-background">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-3">
            <img
              src={logo}
              alt=""
              className="h-8 w-8 rounded-md object-cover"
              width={32}
              height={32}
            />
            <span>© {new Date().getFullYear()} Seunsystems Fintech Global</span>
          </div>
          <span>paywithnaira.name.ng</span>
        </div>
      </footer>
    </div>
  );
}
