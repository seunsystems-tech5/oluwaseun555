# PaySeunsystems Global

I need a website for my company. Company name is Seunsystems Fintech Global and my dns is paywithnaira.name.ng. We are into cross-border payments, Foreign Exchange  and IT managed services. Phone number: 07065759842 instagram: byseunsystems. address: 19a, Allen Avenue, Oshopey Plaza, Ikeja, Lagos. make it also downloadable so i can deploy on aws. attached is my company logo. email: paywithnaira@gmail.com

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/15afd47d-ff97-40f5-972c-22514177ab78).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
